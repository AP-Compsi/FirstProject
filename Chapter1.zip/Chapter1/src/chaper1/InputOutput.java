package chaper1;

import java.text.*;
import java.util.*;

import javax.swing.JOptionPane;

public class InputOutput extends AlexClass {
	
	public static void main(String[] args) {
		String name;
		double number;
		final Scanner scanner = new Scanner(System.in);
		final DecimalFormat decimalFormat= new DecimalFormat("####.00");
		
		System.out.println("Please enter your name");
		
		name = scanner.next();
		
		System.out.println("Please enter your a number");
		number = Double.valueOf(scanner.next());
		System.out.println("My name is "+name+" and the number is "+number+" \nhere is the number formatted "+decimalFormat.format(number));
		
		name = JOptionPane.showInputDialog(null,"Enter your name here","Input Dialog",JOptionPane.QUESTION_MESSAGE);
		JOptionPane.showMessageDialog(null, "Here you are in a dialog box"+name, "Window Title", JOptionPane.INFORMATION_MESSAGE);
	}

	@Override
	public String getDate() {
		// TODO Auto-generated method stub
		return "9/8/2020";
	}
	
	
	
}
