package chaper1;

public abstract class AlexClass {
	
	
	
	public String getAuthor() {
		return "Alex Elguezabal";
	}
	
	public abstract String getDate();

}
